# Unknown2559's Misc. Garbage!
Made with Steam Deck, art will be bad
I used https://thunderstore.io/c/inscryption/p/ArivNidunami/Kaycee_support_cards/
https://thunderstore.io/c/inscryption/p/MADH95Mods/JSONCardLoader/
as references to create the mod

What you can expect from this mod:

  CARDS

- MatPat
- The Sigma
- Game Theory
- Brick Wall

  OTHER

- Sudden "increase" of "skibidi rizz"
- A suspicion about my lack of testing
- Game Theory



New starter deck in the Kaycee's mod deck selector


# Installation

- Working properly with manual installation
- Just copy content in the "plugins" folder to BepInex > plugins
- Sorry for any mistake
- Just for fun
